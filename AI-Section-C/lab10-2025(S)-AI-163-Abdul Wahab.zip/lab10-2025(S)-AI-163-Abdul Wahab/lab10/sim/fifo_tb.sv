`timescale 1ns / 1ps

module fifo_tb();
    logic clk, rst, wr_en, rd_en;
    logic [7:0] din;
    logic [7:0] dout;
    logic full, empty;

    fifo #(.WIDTH(8), .DEPTH(6), .ADDR_WIDTH(3)) dut (.*);

    always #5 clk = ~clk; // 10ns cycle

    initial begin
        clk = 0; rst = 1; wr_en = 0; rd_en = 0; din = 0;
        #15 rst = 0;

        // --- Write Phase: a to f ---
        @(posedge clk);
        wr_en = 1;
        din = "a"; @(posedge clk);
        din = "b"; @(posedge clk);
        din = "c"; @(posedge clk);
        din = "d"; @(posedge clk);
        din = "e"; @(posedge clk);
        din = "f"; @(posedge clk); // FIFO Full here (Pink Line context)
        wr_en = 0;

        repeat(3) @(posedge clk); // Wait before read

        // --- Read Phase (Blue line start) ---
        @(posedge clk);
        rd_en = 1; // Blue line: rd_en goes high
        
        // Yellow line: After first posedge of rd_en, 'a' appears on dout
        repeat(6) @(posedge clk); 
        
        rd_en = 0;
        #50 $stop;
    end
endmodule