module fifo #(
    parameter WIDTH = 8,
    parameter DEPTH = 6,
    parameter ADDR_WIDTH = 3
)(
    input  logic clk,
    input  logic rst,
    input  logic wr_en,
    input  logic [WIDTH-1:0] din,
    input  logic rd_en,
    output logic [WIDTH-1:0] dout,
    output logic full,
    output logic empty
);

    logic [WIDTH-1:0] mem [0:DEPTH-1]; 
    logic [ADDR_WIDTH-1:0] wr_ptr;      
    logic [ADDR_WIDTH-1:0] rd_ptr;      
    logic [ADDR_WIDTH:0] count;

    // Fast Flag Logic: Taake Pink line par hi 'full' low ho jaye
    assign empty = (count == 0);
    assign full  = (count == DEPTH);

    always_ff @(posedge clk) begin
        if (rst) begin
            wr_ptr <= 0;
            rd_ptr <= 0;
            count  <= 0;
            dout   <= 0;
        end else begin
            // Write Logic
            if (wr_en && !full) begin
                mem[wr_ptr] <= din;
                wr_ptr <= (wr_ptr == DEPTH-1) ? 0 : wr_ptr + 1;
            end
            
            // Read Logic: Yellow line se 'a' shuru karne ke liye
            if (rd_en && !empty) begin
                dout <= mem[rd_ptr]; 
                rd_ptr <= (rd_ptr == DEPTH-1) ? 0 : rd_ptr + 1;
            end

            // Counter Update (Combinational path for fast flag response)
            case ({wr_en && !full, rd_en && !empty})
                2'b10: count <= count + 1;
                2'b01: count <= count - 1;
                default: count <= count; // Do nothing or simultaneous R/W
            endcase
        end
    end
endmodule