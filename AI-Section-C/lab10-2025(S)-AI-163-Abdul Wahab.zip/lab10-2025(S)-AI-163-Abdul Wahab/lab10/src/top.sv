module top (
    input  logic clk,
    input  logic [4:0] push_button, // btn[0]=rst, btn[1]=wr, btn[2]=rd
    input  logic [7:0] switch,
    output logic [7:0] led,
    output logic [7:0] pmod_a
);
    logic full, empty;

    fifo #(.WIDTH(8), .DEPTH(6), .ADDR_WIDTH(3)) my_fifo (
        .clk(clk),
        .rst(push_button[0]),
        .wr_en(push_button[1]),
        .din(switch),
        .rd_en(push_button[2]),
        .dout(led),
        .full(full),
        .empty(empty)
    );

    assign pmod_a[0] = full;
    assign pmod_a[1] = empty;
endmodule