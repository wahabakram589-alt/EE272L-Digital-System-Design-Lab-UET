module fsm_tb();
    logic clk, rst, left, right;
    logic La, Lb, Lc, Ra, Rb, Rc;

    fsm dut (
        .clk_slow(clk), .reset(rst),
        .btnL(left), .btnR(right),
        .La(La), .Lb(Lb), .Lc(Lc),
        .Ra(Ra), .Rb(Rb), .Rc(Rc)
    );

    // Clock Generation
    always #5 clk = ~clk;

    initial begin
        // Initialize
        clk = 0; rst = 1; left = 0; right = 0;
        #15 rst = 0; 

        // CASE 1: ONLY LEFT BUTTON
        $display("Testing Case 1: Left Button");
        @(posedge clk); left = 1; 
        @(posedge clk); left = 0; 
        repeat(6) @(posedge clk); // Sequence chalne dein

        // CASE 2: ONLY RIGHT BUTTON
        $display("Testing Case 2: Right Button");
        @(posedge clk); right = 1; 
        @(posedge clk); right = 0; 
        repeat(6) @(posedge clk);

        // CASE 3: BOTH BUTTONS AT ONCE
        $display("Testing Case 3: Both Buttons");
        @(posedge clk); left = 1; right = 1; 
        @(posedge clk); left = 0; right = 0; 
        repeat(6) @(posedge clk);

        $display("All test cases finished!");
        $finish;
    end
endmodule