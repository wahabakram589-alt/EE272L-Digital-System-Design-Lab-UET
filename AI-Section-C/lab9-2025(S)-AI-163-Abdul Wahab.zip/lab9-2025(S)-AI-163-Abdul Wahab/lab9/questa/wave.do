onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /fsm_tb/clk
add wave -noupdate /fsm_tb/rst
add wave -noupdate /fsm_tb/left
add wave -noupdate /fsm_tb/right
add wave -noupdate /fsm_tb/La
add wave -noupdate /fsm_tb/Lb
add wave -noupdate /fsm_tb/Lc
add wave -noupdate /fsm_tb/Ra
add wave -noupdate /fsm_tb/Rb
add wave -noupdate /fsm_tb/Rc
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {0 ns} 0}
quietly wave cursor active 0
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 0
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ns
update
WaveRestoreZoom {0 ns} {329 ns}
