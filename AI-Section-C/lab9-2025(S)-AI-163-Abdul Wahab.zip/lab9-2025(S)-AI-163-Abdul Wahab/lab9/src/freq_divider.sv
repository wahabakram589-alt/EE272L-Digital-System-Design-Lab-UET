module freq_divider (input logic clk, reset, output logic clk_slow);
    logic [25:0] counter;
    always_ff @(posedge clk) begin
        if (reset) {counter, clk_slow} <= 0;
        else if (counter == 25_000_000) begin
            counter <= 0;
            clk_slow <= ~clk_slow;
        end else counter <= counter + 1;
    end
endmodule