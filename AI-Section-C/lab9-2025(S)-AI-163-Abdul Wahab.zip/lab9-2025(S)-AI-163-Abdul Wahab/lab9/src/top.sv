module top (
    input  logic clk,           // FPGA Clock (100MHz)
    input  logic reset_n,       // Reset Button (Active Low)
    input  logic btnL_raw,      // Left Button Input
    input  logic btnR_raw,      // Right Button Input
    output logic [1:0] leds     // Output LEDs
);
    // Internal Signals
    logic reset;
    assign reset = ~reset_n;    // Reset ko logic high mein convert karna
    
    logic clk_slow, sample_pulse;
    logic btnL_sync, btnR_sync;
    logic btnL_clean, btnR_clean;
    logic btnL_pulse, btnR_pulse;

    // 1. Frequency Divider (for Blinking)
    freq_divider i_div (clk, reset, clk_slow);

    // 2. Sample Pulse Generator (for Debouncing)
    sample_pulse_gen i_samp (clk, reset, sample_pulse);

    // 3. Synchronizers (for Metastability)
    synchronizer i_syncL (clk, btnL_raw, btnL_sync);
    synchronizer i_syncR (clk, btnR_raw, btnR_sync);

    // 4. Debouncers (for Noise Removal)
    debouncer i_debL (clk, reset, sample_pulse, btnL_sync, btnL_clean);
    debouncer i_debR (clk, reset, sample_pulse, btnR_sync, btnR_clean);

    // 5. Button Parsers (for Edge Detection)
    button_parser i_parseL (clk, reset, btnL_clean, btnL_pulse);
    button_parser i_parseR (clk, reset, btnR_clean, btnR_pulse);

    // 6. Finite State Machine (FSM)
    fsm i_fsm (clk_slow, reset, btnL_pulse, btnR_pulse, leds);

endmodule