module button_parser (input logic clk, reset, button_in, output logic pulse_out);
    logic delay;
    always_ff @(posedge clk) delay <= (reset) ? 0 : button_in;
    assign pulse_out = button_in & ~delay;
endmodule