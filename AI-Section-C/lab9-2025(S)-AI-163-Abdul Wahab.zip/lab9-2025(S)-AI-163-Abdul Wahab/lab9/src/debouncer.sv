module debouncer (input logic clk, reset, sample_pulse, noisy_in, output logic clean_out);
    logic [2:0] shift_reg;
    always_ff @(posedge clk) begin
        if (reset) shift_reg <= 0;
        else if (sample_pulse) shift_reg <= {shift_reg[1:0], noisy_in};
    end
    assign clean_out = &shift_reg; // Jab teeno bits 1 hon
endmodule