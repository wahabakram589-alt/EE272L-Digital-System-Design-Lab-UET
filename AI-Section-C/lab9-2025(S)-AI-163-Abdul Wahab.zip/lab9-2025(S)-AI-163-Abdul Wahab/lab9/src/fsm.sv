module fsm (
    input  logic clk_slow, reset, btnL, btnR,
    output logic La, Lb, Lc, Ra, Rb, Rc
);

    typedef enum logic [2:0] {IDLE, DELAY, STAGE_1, STAGE_2, STAGE_3} state_t;
    state_t state;
    
    logic l_active, r_active;

    // Sequential Logic for Transitions
    always_ff @(posedge clk_slow or posedge reset) begin
        if (reset) begin
            state <= IDLE;
            l_active <= 0;
            r_active <= 0;
        end else begin
            case (state)
                IDLE: begin
                    if (btnL || btnR) begin
                        state <= DELAY; // Pehle delay state mein jayega
                        l_active <= btnL;
                        r_active <= btnR;
                    end
                end
                DELAY:   state <= STAGE_1; // Yahan se LEDs on hona shuru hongi
                STAGE_1: state <= STAGE_2;
                STAGE_2: state <= STAGE_3;
                STAGE_3: begin
                    state <= IDLE;
                    l_active <= 0;
                    r_active <= 0;
                end
                default: state <= IDLE;
            endcase
        end
    end

    // Combinational Output (States define the filling/holding)
    always_comb begin
        {La, Lb, Lc, Ra, Rb, Rc} = 6'b000000;
        case (state)
            STAGE_1: begin
                if (l_active) La = 1;
                if (r_active) Ra = 1;
            end
            STAGE_2: begin
                if (l_active) {La, Lb} = 2'b11;
                if (r_active) {Ra, Rb} = 2'b11;
            end
            STAGE_3: begin
                if (l_active) {La, Lb, Lc} = 3'b111;
                if (r_active) {Ra, Rb, Rc} = 3'b111;
            end
            default: {La, Lb, Lc, Ra, Rb, Rc} = 6'b000000;
        endcase
    end
endmodule