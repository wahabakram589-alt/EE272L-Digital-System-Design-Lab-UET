module sample_pulse_gen (input logic clk, reset, output logic sample_pulse);
    logic [19:0] cnt;
    always_ff @(posedge clk) begin
        if (reset || cnt == 1_000_000) cnt <= 0;
        else cnt <= cnt + 1;
    end
    assign sample_pulse = (cnt == 1_000_000);
endmodule